import { useEffect, useRef, useState } from 'react'
import {
  Activity, AlertCircle, ArrowUpRight, BadgeCheck,
  CalendarDays, Check, ChevronDown, CircleHelp, ClipboardList, Clock3,
  FileHeart, HeartPulse, LoaderCircle, Menu, Plus, QrCode, ScanLine,
  Search, ShieldCheck, Stethoscope, UserRound, X,
} from 'lucide-react'

const API = (import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000').replace(/\/$/, '')

function normalizeId(value) {
  return value.trim().toUpperCase()
}

function formatDate(value, options = { year: 'numeric', month: 'short', day: 'numeric' }) {
  if (!value) return '—'
  const date = new Date(`${value.slice(0, 10)}T00:00:00`)
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat(undefined, options).format(date)
}

function formatDateTime(value) {
  if (!value) return '—'
  const date = new Date(value)
  if (Number.isNaN(date.getTime())) return value
  return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(date)
}

function getErrorMessage(error) {
  if (error instanceof TypeError) return `Cannot reach server. Check that the backend is running at ${API}.`
  return error.message || 'Something went wrong. Please try again.'
}

function ApiError(message, status, detail) {
  const error = new Error(message)
  error.status = status
  error.detail = detail
  return error
}

async function request(url, options) {
  let response
  try {
    response = await fetch(url, options)
  } catch (error) {
    if (error instanceof TypeError) throw error
    throw new Error('Cannot reach server. Check that the backend is running.')
  }
  const data = await response.json().catch(() => ({}))
  if (!response.ok) {
    if (response.status === 404) throw ApiError('Patient not found', 404, data.detail)
    if (response.status === 422) throw ApiError('Please correct the highlighted form fields.', 422, data.detail)
    throw ApiError(data.detail || `Request failed (${response.status}).`, response.status, data.detail)
  }
  return data
}

function App() {
  const [patient, setPatient] = useState(null)
  const [entryId, setEntryId] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [scanOpen, setScanOpen] = useState(false)
  const [scanError, setScanError] = useState('')
  const [formOpen, setFormOpen] = useState(false)
  const [saving, setSaving] = useState(false)
  const [success, setSuccess] = useState('')
  const [formError, setFormError] = useState('')
  const [fieldErrors, setFieldErrors] = useState({})
  const [form, setForm] = useState({ doctor_name: '', symptoms: '', diagnosis: '', prescription: '', notes: '' })
  const [mobileNav, setMobileNav] = useState(false)
  const scanner = useRef(null)
  const inputRef = useRef(null)
  const lookupController = useRef(null)

  async function loadPatient(rawId) {
    const id = normalizeId(rawId)
    if (!id) {
      setError('Enter a patient ID, such as PAT001.')
      inputRef.current?.focus()
      return
    }
    setLoading(true)
    setError('')
    setSuccess('')
    setPatient(null)
    setEntryId(id)
    lookupController.current?.abort()
    const controller = new AbortController()
    lookupController.current = controller
    try {
      const data = await request(`${API}/patients/${encodeURIComponent(id)}`, { signal: controller.signal })
      if (lookupController.current !== controller) return
      setPatient(data)
      setFormOpen(false)
      setFormError('')
    } catch (err) {
      if (err.name === 'AbortError' || lookupController.current !== controller) return
      setError(err.status === 404 ? `Patient ${id} was not found. Check the ID and try again.` : getErrorMessage(err))
    } finally {
      if (lookupController.current === controller) {
        lookupController.current = null
        setLoading(false)
      }
    }
  }

  async function startScanner() {
    setScanError('')
    setScanOpen(true)
    window.setTimeout(async () => {
      try {
        const { Html5Qrcode } = await import('html5-qrcode')
        const reader = new Html5Qrcode('qr-reader')
        scanner.current = reader
        await reader.start(
          { facingMode: 'environment' },
          { fps: 10, qrbox: { width: 240, height: 240 }, aspectRatio: 1 },
          async (decodedText) => {
            if (!scanner.current) return
            const id = normalizeId(decodedText)
            await stopScanner()
            setScanOpen(false)
            if (!/^PAT\d+$/.test(id)) {
              setPatient(null)
              setError('Invalid QR code. This is not a Smart Health Card. Enter the patient ID below instead.')
              return
            }
            setEntryId(id)
            await loadPatient(id)
          },
          () => {},
        )
      } catch {
        setScanError('Camera unavailable. Allow camera access, or enter the patient ID below.')
      }
    }, 100)
  }

  async function stopScanner() {
    if (!scanner.current) return
    const active = scanner.current
    scanner.current = null
    try {
      if (active.isScanning) await active.stop()
      await active.clear()
    } catch {
      // The scanner may already have stopped after a successful read.
    }
  }

  useEffect(() => () => {
    lookupController.current?.abort()
    void stopScanner()
  }, [])

  async function saveConsultation(event) {
    event.preventDefault()
    setFormError('')
    setFieldErrors({})
    setSuccess('')
    const errors = {}
    for (const key of ['doctor_name', 'symptoms', 'diagnosis']) {
      if (!form[key].trim()) errors[key] = 'This field is required.'
    }
    if (Object.keys(errors).length) {
      setFieldErrors(errors)
      setFormError('Please complete the required fields.')
      return
    }
    setSaving(true)
    try {
      const savedConsultation = await request(`${API}/patients/${encodeURIComponent(patient.patient_id)}/consultations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          doctor_name: form.doctor_name.trim(), symptoms: form.symptoms.trim(),
          diagnosis: form.diagnosis.trim(), prescription: form.prescription.trim(), notes: form.notes.trim(),
        }),
      })
      setForm({ doctor_name: '', symptoms: '', diagnosis: '', prescription: '', notes: '' })
      setFormOpen(false)
      try {
        const updated = await request(`${API}/patients/${encodeURIComponent(patient.patient_id)}`)
        setPatient(updated)
        setSuccess('Consultation saved and added to the patient history.')
      } catch {
        setPatient((current) => current ? {
          ...current,
          consultations: [savedConsultation, ...current.consultations]
            .sort((left, right) => new Date(right.consultation_date) - new Date(left.consultation_date)),
        } : current)
        setSuccess('Consultation was saved. Refresh the patient record to sync the latest history.')
      }
    } catch (err) {
      if (err.status === 422 && Array.isArray(err.detail)) {
        const mapped = {}
        err.detail.forEach((item) => {
          const key = item.loc?.at(-1)
          if (key) mapped[key] = item.msg || 'Please check this field.'
        })
        setFieldErrors(mapped)
        setFormError('Please correct the highlighted form fields.')
      } else setFormError(getErrorMessage(err))
    } finally {
      setSaving(false)
    }
  }

  function updateForm(event) {
    const { name, value } = event.target
    setForm((previous) => ({ ...previous, [name]: value }))
    setFieldErrors((previous) => ({ ...previous, [name]: '' }))
  }

  const consultationCount = patient?.consultations?.length ?? 0

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? 'sidebar-open' : ''}`}>
        <a className="brand" href="#home" onClick={() => { setPatient(null); setError(''); setMobileNav(false) }}>
          <span className="brand-mark"><HeartPulse size={21} strokeWidth={2.3} /></span>
          <span className="brand-text">smart<span>health</span><small>CARE PLATFORM</small></span>
        </a>
        <div className="nav-label">WORKSPACE</div>
        <nav className="nav-list" aria-label="Main navigation">
          <button className="nav-link active" onClick={() => { setMobileNav(false); window.scrollTo({ top: 0, behavior: 'smooth' }) }}><FileHeart size={18} /> Patient records</button>
          <button className="nav-link" onClick={() => { setMobileNav(false); document.getElementById('scan-panel')?.scrollIntoView({ behavior: 'smooth' }) }}><ScanLine size={18} /> Scan patient card</button>
        </nav>
        <div className="sidebar-bottom">
          <div className="demo-note"><span className="demo-note-icon"><ShieldCheck size={18} /></span><div><b>Demo environment</b><small>All records are synthetic</small></div></div>
          <div className="profile-mini"><div className="avatar avatar-doctor">DE</div><div className="profile-info"><b>Demo workspace</b><small>Not a signed-in account</small></div><ChevronDown size={16} className="muted-icon" /></div>
        </div>
      </aside>

      {mobileNav && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setMobileNav(false)} />}
      <main className="main-area" id="home">
        <header className="topbar">
          <button className="icon-button mobile-menu" aria-label="Open menu" onClick={() => setMobileNav(true)}><Menu size={20} /></button>
          <div className="breadcrumb"><span>Workspace</span><span className="crumb-sep">/</span><b>Patient records</b></div>
          <div className="topbar-right"><span className="secure-label"><span className="secure-dot" /> Local demo</span><span className="avatar avatar-doctor top-avatar">DE</span></div>
        </header>

        <div className="content-wrap">
          <section className="page-heading">
            <div><div className="eyebrow"><span className="eyebrow-line" /> PATIENT CARE</div><h1>Patient records</h1><p>Access a patient’s health profile and consultation history.</p></div>
            <div className="heading-status"><span className="status-check"><Check size={14} /></span> Demo environment</div>
          </section>

          <section className="lookup-card" id="scan-panel">
            <div className="lookup-top"><div><div className="section-kicker">PATIENT IDENTIFICATION</div><h2>Find a patient</h2><p>Scan a health card QR code or enter the patient ID manually.</p></div><div className="qr-decoration"><QrCode size={26} strokeWidth={1.6} /></div></div>
            <div className="lookup-actions">
              <button className="scan-button" onClick={startScanner}><span className="scan-button-icon"><ScanLine size={20} /></span><span><b>Scan QR code</b><small>Use your device camera</small></span><ArrowUpRight className="button-arrow" size={17} /></button>
              <div className="or-divider"><span>OR</span></div>
              <form className="manual-form" onSubmit={(event) => { event.preventDefault(); void loadPatient(entryId) }}>
                <label htmlFor="patient-id">Enter patient ID</label>
                <div className={`input-row ${error && !patient ? 'input-error' : ''}`}><Search size={18} className="input-icon" /><input ref={inputRef} id="patient-id" autoComplete="off" placeholder="e.g. PAT001" value={entryId} onChange={(event) => setEntryId(event.target.value)} /><button type="submit" className="lookup-button" disabled={loading}>{loading ? <LoaderCircle size={17} className="spin" /> : <>Find patient <ArrowUpRight size={16} /></>}</button></div>
                <small className="input-hint">Patient IDs are printed on the health card.</small>
              </form>
            </div>
            {scanOpen && <div className="scanner-panel"><div className="scanner-head"><div><b>Scan patient QR</b><small>Position the code inside the frame</small></div><button className="icon-button" onClick={() => { void stopScanner(); setScanOpen(false) }} aria-label="Close scanner"><X size={18} /></button></div><div id="qr-reader" className="qr-reader" />{scanError && <div className="inline-alert"><AlertCircle size={17} />{scanError}</div>}</div>}
            {error && <div className="inline-alert error-alert"><AlertCircle size={17} /><span>{error}</span></div>}
            <div className="lookup-footer"><span><CircleHelp size={15} /> Need help finding an ID?</span><button onClick={() => { setEntryId('PAT001'); inputRef.current?.focus() }}>Try a sample ID <ArrowUpRight size={14} /></button></div>
          </section>

          {patient && <div className="record-area">
            <div className="record-title-row"><div><div className="section-kicker">PATIENT OVERVIEW</div><h2>Health profile</h2></div><span className="record-loaded"><BadgeCheck size={16} /> Record loaded</span></div>
            <section className="patient-card">
              <div className="patient-identity"><div className="avatar avatar-patient"><UserRound size={26} /></div><div><div className="patient-name-row"><h3>{patient.full_name}</h3><span className="id-chip">{patient.patient_id}</span></div><p>Patient profile <span className="dot-separator">·</span> Synthetic record</p></div><div className="patient-id-badge"><span className="tiny-label">PATIENT ID</span><b>{patient.patient_id}</b></div></div>
              <div className="profile-divider" />
              <div className="detail-grid">
                <div className="detail-item"><span className="detail-icon"><CalendarDays size={16} /></span><div><small>Date of birth</small><b>{formatDate(patient.date_of_birth)}</b></div></div>
                <div className="detail-item"><span className="detail-icon"><UserRound size={16} /></span><div><small>Gender</small><b>{patient.gender}</b></div></div>
                <div className="detail-item"><span className="detail-icon blood-icon"><Activity size={16} /></span><div><small>Blood group</small><b className="blood-value">{patient.blood_group}</b></div></div>
              </div>
              <div className="clinical-grid">
                <div className="clinical-box allergy-box"><div className="clinical-heading"><span className="clinical-icon allergy-icon"><AlertCircle size={16} /></span><div><b>Allergies</b><small>Review before treatment</small></div><span className="critical-tag">CRITICAL</span></div><p>{patient.allergies?.trim() || 'None recorded'}</p></div>
                <div className="clinical-box"><div className="clinical-heading"><span className="clinical-icon condition-icon"><HeartPulse size={16} /></span><div><b>Medical conditions</b><small>Reported history</small></div></div><p>{patient.medical_conditions?.trim() || 'None recorded'}</p></div>
              </div>
            </section>

            <section className="history-section">
              <div className="history-heading"><div><div className="section-kicker">CARE TIMELINE</div><h2>Consultation history <span className="count-pill">{consultationCount}</span></h2><p>Latest consultations appear first.</p></div><button className="primary-button" onClick={() => { setFormOpen((open) => !open); setFormError(''); setFieldErrors({}) }}>{formOpen ? <><X size={17} /> Cancel</> : <><Plus size={17} /> Add consultation</>}</button></div>

              {success && <div className="success-banner"><span><Check size={17} /></span>{success}<button onClick={() => setSuccess('')} aria-label="Dismiss"><X size={16} /></button></div>}

              {formOpen && <form className="consultation-form" onSubmit={saveConsultation} noValidate>
                <div className="form-heading"><div className="form-icon"><Stethoscope size={19} /></div><div><h3>New consultation</h3><p>Record the details of today’s visit.</p></div></div>
                {formError && <div className="inline-alert error-alert"><AlertCircle size={17} /><span>{formError}</span></div>}
                <div className="form-grid">
                  <FormField label="Doctor name" name="doctor_name" required value={form.doctor_name} error={fieldErrors.doctor_name} onChange={updateForm} placeholder="e.g. Dr. Sharma" />
                  <FormField label="Symptoms" name="symptoms" required value={form.symptoms} error={fieldErrors.symptoms} onChange={updateForm} placeholder="Describe reported symptoms" />
                  <FormField label="Diagnosis" name="diagnosis" required value={form.diagnosis} error={fieldErrors.diagnosis} onChange={updateForm} placeholder="Enter diagnosis" />
                  <FormField label="Prescription" name="prescription" value={form.prescription} error={fieldErrors.prescription} onChange={updateForm} placeholder="Medication or care plan" />
                  <FormField label="Notes" name="notes" value={form.notes} error={fieldErrors.notes} onChange={updateForm} placeholder="Follow-up notes" wide />
                </div>
                <div className="form-footer"><span><ShieldCheck size={15} /> Saved to this patient’s record</span><button type="submit" className="primary-button" disabled={saving}>{saving ? <><LoaderCircle size={17} className="spin" /> Saving…</> : <><Check size={17} /> Save consultation</>}</button></div>
              </form>}

              {consultationCount === 0 ? <div className="empty-state"><span className="empty-icon"><ClipboardList size={24} /></span><h3>No consultations yet</h3><p>There are no consultation records for this patient. Add the first visit to start their care timeline.</p><button className="text-action" onClick={() => setFormOpen(true)}><Plus size={16} /> Add first consultation</button></div> : <div className="timeline">{patient.consultations.map((item, index) => <article className="consultation-card" key={item.id}><div className="timeline-rail"><span className={`timeline-node ${index === 0 ? 'latest-node' : ''}`} /><span className="timeline-line" /></div><div className="consultation-content"><div className="consultation-top"><div><div className="consultation-date"><Clock3 size={14} /> {formatDateTime(item.consultation_date)} {index === 0 && <span className="latest-tag">LATEST</span>}</div><h3>{item.diagnosis}</h3></div><span className="doctor-name"><Stethoscope size={14} /> {item.doctor_name}</span></div><div className="consultation-facts"><div><small>Symptoms</small><p>{item.symptoms || '—'}</p></div><div><small>Prescription</small><p>{item.prescription?.trim() || 'None recorded'}</p></div>{item.notes?.trim() && <div className="notes-row"><small>Notes</small><p>{item.notes}</p></div>}</div></div></article>)}</div>}
            </section>
          </div>}

          {!patient && !loading && <section className="welcome-card"><span className="welcome-art"><span className="art-circle"><HeartPulse size={27} /></span><span className="art-spark spark-one">✳</span><span className="art-spark spark-two">✦</span></span><div><h2>Your patient workspace</h2><p>Scan a card or enter a patient ID to open a health profile and care history.</p></div><div className="welcome-steps"><span><i>1</i> Identify patient</span><ArrowUpRight size={15} /><span><i>2</i> Review record</span><ArrowUpRight size={15} /><span><i>3</i> Add consultation</span></div></section>}

          <footer className="page-footer"><span><ShieldCheck size={14} /> Smart Health Card <span className="footer-dot">·</span> Synthetic data only</span><span>For demonstration purposes</span></footer>
        </div>
      </main>
    </div>
  )
}

function FormField({ label, name, required, value, error, onChange, placeholder, wide }) {
  const id = `field-${name}`
  return <div className={`form-field ${wide ? 'field-wide' : ''}`}><label htmlFor={id}>{label}{required && <span className="required-star"> *</span>}</label>{wide ? <textarea id={id} name={name} value={value} onChange={onChange} placeholder={placeholder} rows={3} aria-invalid={Boolean(error)} /> : <input id={id} name={name} value={value} onChange={onChange} placeholder={placeholder} aria-invalid={Boolean(error)} />}{error && <small className="field-error">{error}</small>}</div>
}

export default App
